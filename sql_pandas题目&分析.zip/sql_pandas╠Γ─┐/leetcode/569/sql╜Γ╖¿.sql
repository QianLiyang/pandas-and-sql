# Write your MySQL query statement below
select id ,company ,salary
from
(select id,company,salary,
    count(1)over(partition by company) as num,
    dense_rank()over(partition by company order by salary,id) as rk  
from Employee )temp1  
where num %2 != 0 and rk=ceil(num/2)
union 
select id ,company ,salary
from
(select id,company,salary,
    count(1)over(partition by company) as num,
    dense_rank()over(partition by company order by salary,id) as rk
from Employee )temp1
where num %2 = 0 and rk in(num/2,num/2+1);


# 方法二
select id ,company ,salary
from
(select id,company,salary,
    count(1)over(partition by company) as num,
    dense_rank()over(partition by company order by salary,id) as rk  # rank能起到indx的作用
from Employee )temp1
where rk in(num/2,num/2+1,ceil(num/2))

# 方法三


