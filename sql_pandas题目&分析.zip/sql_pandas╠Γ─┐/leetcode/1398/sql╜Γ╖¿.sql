# Write your MySQL query statement below
SELECT o.customer_id customer_id,
        c.customer_name customer_name
FROM Orders o
LEFT JOIN Customers c  USING(customer_id)
GROUP BY customer_id
HAVING 
        SUM(IF(product_name='A',1,0))>0 AND
        SUM(IF(product_name='B',1,0))>0 AND
        SUM(IF(product_name='C',1,0))=0

# 我的：
select customer_id,customer_name
from(
select distinct customer_id
from orders o1
where "A" in (select product_name from orders o2 where  o2.customer_id=o1.customer_id)
    and "B" in (select product_name from orders o2 where  o2.customer_id=o1.customer_id)
    and "C" not in  (select product_name from orders o2 where  o2.customer_id=o1.customer_id))t
join Customers using (customer_id)
