select min(log_id) as start_id ,max(log_id) as end_id 
from(
    select  log_id, rk , log_id-rk as diff
    from(
        select log_id,dense_rank()over(order by log_id) as rk 
        from Logs)temp1
)temp2
group by diff
