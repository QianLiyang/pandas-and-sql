# Write your MySQL query statement below
select team_id , team_name,ifnull(sum(bouns),0) as num_points
from teams
left join(select if(host_goals>guest_goals,host_team,guest_team) as team_id ,3 as bouns
            from Matches 
            where host_goals!=guest_goals 
            union all  
            select host_team,1
            from Matches 
            where host_goals=guest_goals 
            union all 
            select  guest_team,1
            from Matches 
            where host_goals=guest_goals)t using(team_id)
group by team_name 
order by num_points desc,team_id