select round((count(id)/(select count(distinct player_id) from Activity)),2) as fraction
from(
select distinct id
from(select player_id as id,
        lead(event_date,1)over(partition by player_id order by event_date) as ld,
        event_date as nd,
        dense_rank()over(partition by player_id order by event_date) as rk
    from Activity)temp
where datediff(ld,nd)=1 and rk=1)temp2

# https://leetcode.cn/problems/game-play-analysis-iv/description